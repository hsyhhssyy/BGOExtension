﻿

var findCardTaken = /([\s\S]*?) takes ([\s\S]*?) in hand/;
var findCardPutBack = /([\s\S]*?) puts ([\s\S]*?) back/;


var totalWl=undefined;

function collectTotalWl(match,color) {
    if (totalWl == undefined) {
        totalWl= {
            "total": 0,
            "win": 0,
            "lose": 0,
            "tie": 0,
            "resign":0
        }
    }

    totalWl.total += 1;
    if (match.wl == "Win") {
        totalWl.win += 1;
    } else if (match.wl == "Lose") {
        totalWl.lose += 1;
    } else if (match.wl == "Tie") {
        totalWl.tie += 1;
    } else if (match.wl == "Resign") {
        totalWl.resign += 1;
    }

}

function collectTotalWlFinished() {
    if (totalWl == undefined) {
        totalWl = {
            "total": 0,
            "win": 0,
            "lose": 0,
            "tie": 0,
            "resign": 0
        }
    }

    if (totalWl.total == 0) {
        $("#statistic-status")[0].innerHTML = "0 match analyzed.";
    } else {
        $("#statistic-status")[0].innerHTML = "A total of " + totalWl.total + " match(es) analyzed: Win " + totalWl.win + "(" + (100 * totalWl.win / totalWl.total).toFixed(2) + "%), Lose " + totalWl.lose + "(" + (100 * totalWl.lose / totalWl.total).toFixed(2) +
            "%), Tie " + totalWl.tie + "(" + (100 * totalWl.tie / totalWl.total).toFixed(2) + "%), Resign " + totalWl.resign + "(" + (100 * totalWl.resign / totalWl.total).toFixed(2) + "%)";
    }

}

function collectCardTaken(match, color) {
    var journal = match.journal;


    //Process Journal
    var i = 1;
    for (var i = 1; journal[i] != undefined; i++) {
        var log = journal[i];
        var text = log.journal;

        var card = undefined;
        var num = 0;

        var arrMatches = text.match(findCardTaken)
        if (arrMatches != null) {
            var player = arrMatches[1];
            if (player == color) {
                var card = arrMatches[2];
                var age = log.age;
                num = 1;
            }
        }


        arrMatches = text.match(findCardPutBack)
        if (arrMatches != null) {
            var player = arrMatches[1];
            if (player == color) {
                var card = arrMatches[2];
                var age = log.age;
                num = -1;
            }
        }

        if (card != undefined) {
            if (cardStatistics[card] == undefined) {
                cardStatistics[card] = {
                    taken: 0,
                    win: 0,
                    lose: 0,
                    tie: 0,
                    resign: 0
                };
            }

            cardStatistics[card].taken += num;
            if (match.wl == "Win") {
                cardStatistics[card].win += num;
            } else if (match.wl == "Lose") {
                cardStatistics[card].lose += num;
            } else if (match.wl == "Tie") {
                cardStatistics[card].tie += num;
            } else if (match.wl == "Resign") {
                cardStatistics[card].resign += num;
            }
        }
    }

}


function collectCardTakenFinished() {
    for (var card in cardStatistics) {
        var status = cardStatistics[card];

        var tr = $("#card-list-simple").first().clone();
        tr[0].removeAttribute("hidden");
        tr.find("#card-name")[0].innerHTML = card;
        tr.find("#card-taken")[0].innerHTML = status.taken;
        tr.find("#card-win")[0].innerHTML = status.win;
        tr.find("#card-lose")[0].innerHTML = status.lose;
        tr.find("#card-tie")[0].innerHTML = status.tie;
        tr.find("#card-resign")[0].innerHTML = status.resign;

        $("#card-list").append(tr);

    }

    $("#card-list")[0].removeAttribute("hidden");
}

function judgePlayerColor(match) {
    var colors = match.playerColors;

    var color = undefined;
    for (var name in colors) {
        if (aliasNames.indexOf(name) >= 0) {
            color = colors[name];
        }
    }

    if (color != undefined) {
        color = color.substr(0, 1).toUpperCase() + color.substr(1).toLowerCase();
    }
    return color;
}

function analyzeSelectedMatch() {


    if (matches.length <= 0) {
        $("#statistic-status")[0].innerHTML = "Please list matches first.";
        return;
    }

    var matchToAnalyze = [];

    for (var i = 0; i < matches.length; i++) {
        var checkbox = $('tr[aindex="' + i+'"]').find("#analyze-this-match")[0];
        if (checkbox != undefined&&checkbox.checked==true) {
            matchToAnalyze[matchToAnalyze.length] = matches[i];
        }
    }

    //重置所有分析结果
    cardStatistics = [];
    var totalWl = undefined;

    for (var i = 0; i < matchToAnalyze.length; i++) {
        var match = matchToAnalyze[i];

        var playerColor = judgePlayerColor(match);

        if (playerColor == undefined) {
            //将有问题的比赛颜色变一下
            var tr = $('tr[mindex="' + match.id + '"]');
            var tds = tr.find("td");

            for (var j = 0; tds[j] != undefined; j++) {
                tds[j].setAttribute("class", "batiment1 tta_production1");
            }
            continue;
        }
        collectCardTaken(match, playerColor);
        collectTotalWl(match, playerColor);
    }

    collectCardTakenFinished();
    collectTotalWlFinished();
}


