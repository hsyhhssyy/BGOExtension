﻿/** ***********************
**
** 给腐败状态栏加入文本提示
**
** ************************/

//statusBar
extensionTools.executeReady(ttaBoardInformation,function() {



});